// This file causes the Arduino IDE to see the Serial examples as a valid library 
